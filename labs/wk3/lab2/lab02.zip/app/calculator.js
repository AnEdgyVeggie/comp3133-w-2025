function add(i, j) {
	return i + j;
};

function mul(i, j) {
	return i * j;
};

function div(i, j) {
	return i / j;
};

function sub(i, j) {
	return i - j;
};